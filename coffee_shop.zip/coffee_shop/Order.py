from Menu import menu

orders = []


def add_order():
    name = input("نام محصول: ")

    if name not in menu:
        print("متاسفانه این محصول در منوی کافه وجود ندارد.")
        return

    quantity = int(input("تعداد: "))
    orders.append({
        "name": name,
        "price": menu[name],
        "quantity": quantity,
    })


def show_orders():
    if len(orders) == 0:
        print("هنوز سفارشی ثبت نشده است.")
        return

    for order in orders:
        print(f"{order['name']} - قیمت: {order['price']:,} تومان - تعداد: {order['quantity']}")
